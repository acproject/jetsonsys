#!/bin/sh

set -e

password=$1

cd ~

echo $password | sudo -S pip3 install traitlets

# install jupyter lab
echo $password | sudo -S apt install -y nodejs npm
echo $password | sudo -S pip3 install -U jupyter jupyterlab
echo $password | sudo -S jupyter labextension install @jupyter-widgets/jupyterlab-manager
echo $password | sudo -S jupyter labextension install @jupyterlab/statusbar
jupyter lab --generate-config


# set jupyter password
python3 -c "from notebook.auth.security import set_password; set_password('$password', '$HOME/.jupyter/jupyter_notebook_config.json')"

# install jetcard
echo $password | sudo -S python3 setup.py install


# install jetcard display service
python3 -m jetcard.create_display_service
echo $password | sudo -S mv jetcard_display.service /etc/systemd/system/jetcard_display.service
echo $password | sudo -S systemctl enable jetcard_display
echo $password | sudo -S systemctl start jetcard_display

# install jupyter_clickable_image_widget
echo $password | sudo -S npm install -g typescript
git clone https://github.com/jaybdub/jupyter_clickable_image_widget
cd jupyter_clickable_image_widget

# allow next command to fail
set +e
echo $password | sudo -S python3 setup.py build

set -e
echo $password | sudo -S npm run build
echo $password | sudo -S pip3 install .
echo $password | sudo -S jupyter labextension install .
echo $password | sudo -S jupyter labextension install @jupyter-widgets/jupyterlab-manager

cd  ~
